#pragma once
#include"Student.h"
void viewClass(Student st) {
    //system("cls");
    //Class* new_class = st.student_class;
    //drawText(baseX, 7, "Classname: " + new_class->name); cout << endl;
    //drawText(baseX, 8, "Student list: "); cout << endl;
    //int i = 9, index = 1;
    //for (Iterator<Student> iter = new_class->student_list.begin(); iter != new_class->student_list.end(); iter++) {
    //    Student k = *iter;
    //    drawText(baseX + 1, i++, to_string(index) + ". " + k.user_info.firstname + " " + k.user_info.lastname); cout << endl;
    //    index++;
    //}
    ////getch();
    //system("cls");
}