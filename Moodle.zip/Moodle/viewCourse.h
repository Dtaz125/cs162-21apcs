#pragma once
#include"Student.h"

void viewCourse(Student st) {
   
}