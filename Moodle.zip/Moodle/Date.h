#ifndef DATE_H
#define DATE_H
struct Date {
	int day = 0;
	int month = 0;
	int year = 0;
};
#endif // !DATE_H
