#pragma once
#include <iostream>
#include"Student.h"
using namespace std;

void drawScoreboard(const Student& st) {

}