#ifndef DATE_H
#define DATE_H
struct Date {
	int day;
	int month;
	int year;
};
#endif // !DATE_H
