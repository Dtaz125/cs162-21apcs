#include"Student.h"
#include<iostream>
using namespace std;
int main() {
	Student student_1;
	student_1.setUsername("tkphat21");
	student_1.setPassword("1234");
	cout << student_1.getUsername() << ' ' << student_1.getPassword() << endl;
	return 0;
}